<?php
class Election extends MX_Controller 
{

function __construct() {
parent::__construct();
}

function dashboard(){
	$data['view_file'] = "election_home";
	$data['module'] = "election";
	$this->load->module('template');
	$this->template->admin_home($data);
}




























function get($order_by){
$this->load->model('mdl_election');
$query = $this->mdl_election->get($order_by);
return $query;
}

function get_with_limit($limit, $offset, $order_by) {
$this->load->model('mdl_election');
$query = $this->mdl_election->get_with_limit($limit, $offset, $order_by);
return $query;
}

function get_where($id){
$this->load->model('mdl_election');
$query = $this->mdl_election->get_where($id);
return $query;
}

function get_where_custom($col, $value) {
$this->load->model('mdl_election');
$query = $this->mdl_election->get_where_custom($col, $value);
return $query;
}

function _insert($data){
$this->load->model('mdl_election');
$this->mdl_election->_insert($data);
}

function _update($id, $data){
$this->load->model('mdl_election');
$this->mdl_election->_update($id, $data);
}

function _delete($id){
$this->load->model('mdl_election');
$this->mdl_election->_delete($id);
}

function count_where($column, $value) {
$this->load->model('mdl_election');
$count = $this->mdl_election->count_where($column, $value);
return $count;
}

function get_max() {
$this->load->model('mdl_election');
$max_id = $this->mdl_election->get_max();
return $max_id;
}

function _custom_query($mysql_query) {
$this->load->model('mdl_election');
$query = $this->mdl_election->_custom_query($mysql_query);
return $query;
}

}