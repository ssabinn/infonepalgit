
<div id="content">
		<h2>Dashboard</h2>
		<div class="admin-home col-sm-12">
			<div class="admin-options col-sm-3"><?php echo anchor("parties/manage", "Parties"); ?></div>
			<div class="admin-options col-sm-3"><?php echo anchor("candidates/manage", "Candidates"); ?></div>
			<div class="admin-options col-sm-3"><?php echo anchor("election/dashboard", "Add Data"); ?></div>
			<div class="admin-options col-sm-3"><?php echo anchor("election/dashboard", "Add Data"); ?></div>
		</div>

</div>