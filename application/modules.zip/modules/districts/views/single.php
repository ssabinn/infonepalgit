<h4>ELECTION OVERVIEW</h4>
<div id="district-name-details">
	<h2><?php echo $district; ?></h2><br/>
</div>
<div id="overview-details">
	<span><b>Election Zones: &nbsp;</b><?php echo $zone_count; ?></span><br/>
	<span><b>Population: &nbsp;</b><?php echo $population; ?></span><br/>
	<!-- <span><b>Competing Parties: &nbsp;</b><?php echo $parties_count; ?></span><br/> -->
</div>