<div id="contact" class="post col-xs-12">

	<div id="contactleft" class="col-sm-7">
		<p>
			This web portal is a brain child of Data Research and Analysis Centre team. We aim at creating a single integrated web site to contain all the information about our country Nepal. The beta version of thus portal contains the election data analysis results. Over time, with the involvement of users group, this site will evolve into a huge, integrated collection of data. 
For the data validity reasons, the information feed up process is authorized to a small team of people for now. But, soon we will enlarge the domain of our information seeders to put up a collaborative environment for collection and dissemination of data and information. 
We believe data should be free and open, easily accessible and transparent. We request you to join hands with us. Together, our effort can result a great user friendly portal


		</p>
		<br/><br/><br/>
		<div class=''><p>Team InfoNepal</p></div>
		<div class=''><p>Data Research and Analysis Center</p></div>
		<div class=''><p>Patan Dhoka, Pulchowk</p><p> Lalitpur Nepal</p></div>
	</div>
	<div id="contactright" class="col-sm-5">
	
	</div>
</div>