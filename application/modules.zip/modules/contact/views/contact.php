<div id="contact" class="post col-xs-12">

	<div id="contactleft" class="col-sm-7">
		<form action="" method="post" id="contact-form">
		    <div id="">
		   		<input name="name" id="name" type="text" placeholder="Name / Surname" /><br/>
		        <input name="email" id="email" type="text" placeholder="Your email address" /><br/>
		        <textarea name="message" id="message" cols="20" rows="8"></textarea>  <br/>
		        <input name="" type="submit" class="envoyer" placeholder="Submit">             
		    </div>
		</form>
	</div>
	<div id="contactright" class="col-sm-5">
		<div class=''><p>Team InfoNepal</p></div>
		<div class=''><p>Data Research and Analysis Center</p></div>
		<div class=''><p>Patan Dhoka, Pulchowk, Lalitpur Nepal</p></div>
	</div>
</div>