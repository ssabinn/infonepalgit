<!DOCTYPE html>
<html>


<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Info Nepal :: Your Portal to Nepal </title>

		<!-- <link rel="shortcut icon" href="<?php echo base_url();?>images/favicon.ico">
		<link rel="apple-touch-icon" href="<?php echo base_url();?>images/favicon.ico"> -->

		<link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap.min.css" type="text/css" media="screen" />
		<link rel="stylesheet" href="<?php echo base_url();?>css/style.css" type="text/css" media="screen" />

		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600|PT+Serif:400,400italic'>

		<script src="<?php echo base_url();?>js/jquery.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>

		<script type="text/javascript">

		$(function(){
		    var BigDay = new Date("20 Nov 2013, 00:00:00");
		    var msPerDay = 24 * 60 * 60 * 1000 ;

		    window.setInterval(function(){
		        var today = new Date();
		        var timeLeft = (BigDay.getTime() - today.getTime());

		        var e_daysLeft = timeLeft / msPerDay;
		        var daysLeft = Math.floor(e_daysLeft);

		        // var e_hrsLeft = (e_daysLeft - daysLeft)*24;
		        // var hrsLeft = Math.floor(e_hrsLeft);

		        // var e_minsLeft = (e_hrsLeft - hrsLeft)*60;
		        // var minsLeft = Math.floor(e_minsLeft);

		        // var e_secsLeft = (e_minsLeft - minsLeft)*60;
		        // var secsLeft = Math.floor(e_secsLeft);


		        var timeString = daysLeft;
		        // alert(timeString);
		        $('#days-left').html(timeString);
		    }, 1000);
		})
		</script>
	</head>

	<body class="container">
			<header>
				<div id="topbar" class="col-sm-12">
					<div class="col-md-4">
						<div id="logo" class="col-xs-8">
							<a href="<?php echo base_url();?>"><img src="<?php echo base_url();?>images/logo.png" /></a>
						</div>
						<div id="logo-event" class="col-xs-4">
							<span>ELECTION</span>
							<div class="clearfix"></div>
							<span id="days-left"></span>
							<div class="clearfix"></div>
							<span>DAYS LEFT</span>
						</div>
					</div>
				
					<div id="header-text" class="col-md-3">
						<p style="color:#e51717;">हामी नेपाली । हाम्रो नेपाल । जय नेपाल ।</p>
					</div>

					<div class="col-md-5">
						<div class="col-sm-12">
							<img id="nepal-flag" src="<?php echo base_url();?>images/nepal_flag.gif"/>
						</div>
						<div class="clearfix"></div>
						<div id="navigation" class="navbar navbar-collapse col-sm-12">
							<ul>
								<li><a href="<?php echo base_url();?>users/logout/">Logout</a></li>
							</ul>
						</div>
		
				</div>
				<div class="clearfix"></div>

				<!-- <div id="header-right" class="col-sm-12">
					
				</div> -->

			</header>
			<div class="clearfix"></div>
