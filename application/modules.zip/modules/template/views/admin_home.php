
<?php
	$this->load->view('admin_header');
	$this->load->view($module."/".$view_file);
?>
