<div id="content">
	<div id="election-data">
		<div id="map" class="col-md-8">
			<h4>VIEW CANDIDATES</h4>

			<?php 
				$this->load->module('map');
				$this->map->show_map();
			?>

			<style type="text/css">
				[id^='district'] path{
			        cursor:pointer;
					-webkit-transform:scale(1,1);

			    }
			    [id^='district']:hover path{
			        fill:#e41616;
			        }   
			        
			    [id^='district'] text{
			        cursor:pointer;
					display:none;
					font-family:Arial,San-serif;
			    }
			</style>

			
			<div id="view-candidate" class="col-sm-12 view-candidate">
				<form name="district_form" method="post" action="districts/districtArea" class="form-horizontal">
					
					<div class="col-sm-5">
					<label for="district">DISTRICT : </label>
					
						<select class="select-district" name="district" class="">
                			<option value="0" disabled selected>Select District</option>
							<?php
								$this->load->module('districts');
								$query = $this->districts->get('district_name');
								foreach ($query->result() as $row) {
									echo "<option value=".strtolower($row->district_name).">".$row->district_name."</option>";
								}
							?>
                        </select>
					</div>
					<div class="col-sm-5">
					<label for="district">AREA : </label>					
						<select class="select-area" name="area" class="">
							<option value="0" disabled>Select Area:</option>
          
                        </select>
                    </div>
                    <div class="col-sm-2">
                    	<input type="submit" name="submit" value="VIEW">
                    </div>
                   
				</form>				
			</div>
			<!-- <div id="view-candidate-small" class="col-xs-12">
				<form name="district_form" method="post" action="districts/districtArea" class="form-horizontal">

					<label for="district">DISTRICT : </label>

						<select class="select-district" name="district" class="">
                			<option value="0" disabled selected>Select District</option>
							<?php
								$this->load->module('districts');
								$query = $this->districts->get('district_name');
								foreach ($query->result() as $row) {
									echo "<option value=".strtolower($row->district_name).">".$row->district_name."</option>";
								}
							?>
                        </select>
					<br/><br/>
					<label for="district">AREA : </label>
		
						<select class="select-area" name="area" class="">
							<option value="0" disabled>Select Area:</option>
          
                        </select>
                    <br/><br/>
                    <input type="submit" name="submit" value="View"><br/>

				</form>				
			</div> -->
		</div>
		<div id="election-overview" class="col-md-4">
			<h4>ELECTION OVERVIEW</h4>
			<div id="district-name-details"></div>
			<div class="overview-details" id="overview-details-all">
				<span><b>Election Zones: &nbsp;</b>575</span><br/>
				<span><b>Voting Population: &nbsp;</b>1,76,09,895</span><br/>
				<span><b>Competing Parties: &nbsp;</b>130</span><br/><br/>
				<span ><b>What You Need For Election:</b></span><br/><br/>
				
				<div id="election-extra-details">
					<p>	(क) संघ/संस्था दर्ताको प्रमाणपत्रको प्रतिलिपि,</p>
					<p>	(ख) त्यस्तो संघ/संस्था नवीकरण भएको निस्साको प्रतिलिपि,</p>
					<p>	(ग) संघ/संस्थाको विधानको प्रतिलिपि,</p>
					<p>	(घ) संघ/संस्थाको कार्यक्रम एवं लेखापरीक्षण प्रतिवेदनको प्रतिलिपि,</p>
					<p>	(ङ) संस्थाका कार्य समितिका पदाधिकारीहरूको नामावली,</p>
					<p>	(च) विगतमा गरेका राष्ट्रिय/अन्तर्राष्ट्रिय निर्वाचन पर्यवेक्षणको अनुभव भए सो को प्रमाण,</p>
					<p>	(छ) पर्यवेक्षण सम्बन्धमा संघ/संस्थाले तयार पारेको ब्रोसर, पुस्तिका, निर्देशिका वा अन्य कुनै प्रकाशन भए सो समेत,</p>
					<p>	(ज) संघ/संस्थाले तयार गरेको पर्यवेक्षक परिचालन सम्वन्धी नीति ।</p>
				</div>
			</div>
			<div class="overview-details" id="overview-details" style="display:none;">
				
			</div>
		</div>


	</div>
	<div class="clearfix"></div>

	<div id="charts" class="col-sm-12">
		<div class="col-sm-6" id="chart_div" class="col-md-6">
			<img src="<?php echo base_url(); ?>/images/chart1.png" class="img-responsive" />
			<div class="clearfix"></div>
			<h4><b>Total Voting Population in Past Years</b></h4>
		</div>
		<div class="col-sm-6" id="chart_div" class="col-md-6">
			<img src="<?php echo base_url(); ?>/images/chart2.png" class="img-responsive" />
			<div class="clearfix"></div>
			<h4><b>Percentage change in Voting Population</b></h4>
		</div>
	</div>

	<div class="clearfix"></div>

	<div id="recent-posts">		
		<div id="rss-feed" class="recent col-md-6">
			<h2>RSS Feed CNN.com</h2>	
			<?php foreach ($rss_news as $row) { ?>
			<p><a href="<?php echo $row['link']; ?>"><?php echo $row['title']; ?></a></p>
			<?php }?>
		</div>

		<div id="recent-news" class="recent col-md-6">
			<h2>News</h2>
			<?php foreach ($news_query->result() as $row) { ?>
			<p><a href="news/posts/<?php echo $row->news_url; ?>"><?php echo $row->news_headline; ?></a></p>
			<?php }?>
			<!-- <p><?php 
				$this->load->helper('text');
				echo word_limiter($news_content, 100); ?></p>
			<a href="news/posts/<?php echo $news_url?>" class="btn btn-default">Read More</a> -->
		</div>
		<!-- <div id="recent-blog" class="recent col-md-6">
			<h2>Blog</h2>
			<h3><a href="blogs/posts/<?php echo $blog_url; ?>"><?php echo $blog_title; ?></a></h3>
			<p><?php echo word_limiter($blog_content, 100); ?></p>
			<a href="blogs/posts/<?php echo $blog_url?>" class="btn btn-default">Read More</a>
		</div> -->

	</div>
</div>

<script type="text/javascript">
		$(".select-district").on("change", function(){
			var newDistrictName = $(".select-district").val();
			$('.district path').css("fill", "#93c6ea");
			$('#district-'+newDistrictName+' path').css("fill", "#e51717");
			
			// show district details on sidebar

			$("#district-name-details").html("<h2>"+newDistrictName+"</h2>");
			$("#district-name-details").show();
			$("#overview-details-all").hide();
			$("#overview-details").show();

			var request = $.ajax({
					url: "districts/get_sidebar_option/",  // the file to be called
					type: "POST",	   // post method to be used
					data: {district: newDistrictName},   // data to be sent (eg. username:nj)
					dataType: "text"        // type of data expected
			});
			request.done(function( data ) {
				$("#overview-details").html("");
				var parts = data.split('-');
				console.log(newDistrictName);
				console.log(parts[0]);
				console.log(parts[1]);
				$("#overview-details").append("<span><b>Election Zones: &nbsp;</b>"+parts[1]+"</span><br/><br/>");			
				$("#overview-details").append("<span><b>Voting Population: &nbsp;</b>"+parts[0]+"</span><br/><br/>");			
			});

			// what if there was an error?
			request.fail(function( jqXHR, textStatus ) {
				alert( "Request failed: " + textStatus );
			});


			// get area select options

			$.ajax({
				type: "GET",
				url: "<?php base_url();?>districts/get_where_district/"+$(".select-district").val(), 
				data: {district: $(".select-district").val()},
				dataType: "text",  
				cache:false,
				success: 
				  function(data){				
				  	// alert(data);
				    $(".select-area").html("");
						for(i=1; i<= parseInt(data); i++){
							$(".select-area").append('<option value="'+i+'">'+i+'</option>');
						}
					}
			});
			return false;
		});
</script>
		

<?php
	$this->load->view('footer');
?>