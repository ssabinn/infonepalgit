<?php
class Rss_reader extends MX_controller{
	

	function get_rss(){
		//loading rssparser library
		// $this->load->library('rssparser');

		// setting the rss url to be used source: cnn.com
			//address for top stories
		$this->rssparser->set_feed_url('http://rss.cnn.com/rss/edition.rss');
			//address for world news
			// $this->rssparser->set_feed_url('http://rss.cnn.com/rss/edition_world.rss');
			// //address for business news
			// $this->rssparser->set_feed_url('http://rss.cnn.com/rss/edition_business.rss');
			// //address for sports
			// $this->rssparser->set_feed_url('http://rss.cnn.com/rss/edition_sport.rss');


		// rss results limit to 6 number of records
		$data['rss_news']= $this->rssparser->getFeed(6);
		/**
		 * @param $news contains only 5 fields by default: 
		 * title, description, pubDate, link, author
		 */
		
		// var_dump($data);
		// var_dump($rss_news);
		// var_dump($rss_news[0]);

		// cache life in minutes
		// $this->rssparser->set_cache_life(60); 
		
		//testing the result by echoing
		// foreach($news as $records){
			// echo '<b> Title: </b>' . $records['title'].'<br>';
			// echo '<b> Description: </b>' . $records['description'].'<br>';
			// echo '<b> Published Date: </b>' . $records['pubDate'].'<br>';
			// echo '<b> Anchor: </b>' . $records['link'].'<br>';
			// echo '<b> Author: </b>' . $records['author'].'<br><br><br>';
			//echo '<pre>'.print_r($news).'</pre><br>';
		// }

		return $data;
		//loading into the view
		//$this->load->view('display_news',$news);
	}
}